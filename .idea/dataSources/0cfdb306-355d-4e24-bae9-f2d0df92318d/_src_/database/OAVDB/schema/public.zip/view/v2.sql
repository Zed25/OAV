CREATE VIEW v2 AS SELECT f1.source AS v2source,
    (f1.value - f2.value) AS difvalue3645
   FROM (fluxes f1
     JOIN fluxes f2 ON (((f1.source)::text = (f2.source)::text)))
  WHERE (((f1.band = (3.6)::double precision) OR (f2.band = (4.5)::double precision)) AND ((f1.value - f2.value) > (0.7)::double precision));
