CREATE VIEW v1 AS
SELECT f1.source AS v1source,
    (f1.value - f2.value) AS difvalue4558
   FROM (fluxes f1
     JOIN fluxes f2 ON (((f1.source)::text = (f2.source)::text)))
  WHERE (((f1.band = (4.5)::double precision) OR (f2.band = (5.8)::double precision)) AND ((f1.value - f2.value) > (0.7)::double precision))